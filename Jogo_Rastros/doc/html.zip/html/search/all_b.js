var searchData=
[
  ['obter_5fcoord_5fbranca',['obter_coord_branca',['../auxiliares_8h.html#a7efad7ce8f98e281be10a2e537de68cb',1,'obter_coord_branca(ESTADO *e):&#160;auxiliares.c'],['../camada__logica_8h.html#a7efad7ce8f98e281be10a2e537de68cb',1,'obter_coord_branca(ESTADO *e):&#160;auxiliares.c']]]
];
