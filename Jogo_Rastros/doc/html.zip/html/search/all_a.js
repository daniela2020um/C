var searchData=
[
  ['nodo',['nodo',['../structnodo.html',1,'']]],
  ['num',['num',['../camada__interface_8h.html#a70bfbeadc5be12c9cb3110cba47c2694',1,'auxiliares.c']]],
  ['num_5fjogadas',['num_jogadas',['../structESTADO.html#a261495728744647e618b4e623f5a4b7a',1,'ESTADO']]]
];
