var searchData=
[
  ['jogadas_5fpossiveis',['jogadas_possiveis',['../auxiliares_8h.html#a1aea03240fe093e7eef97e0412298e7b',1,'jogadas_possiveis(ESTADO *e, LISTA l):&#160;auxiliares.c'],['../camada__logica_8h.html#a1aea03240fe093e7eef97e0412298e7b',1,'jogadas_possiveis(ESTADO *e, LISTA l):&#160;auxiliares.c']]],
  ['jogar',['jogar',['../camada__interface_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;camada_logica.c'],['../camada__logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;camada_logica.c']]]
];
