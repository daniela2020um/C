var searchData=
[
  ['jog1',['JOG1',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039a8ff080ca8f3143a71121a37a8e6596d8',1,'JOG1():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039a8ff080ca8f3143a71121a37a8e6596d8',1,'JOG1():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a8ff080ca8f3143a71121a37a8e6596d8',1,'JOG1():&#160;camada_dados.h']]],
  ['jog2',['JOG2',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039a15421bcb42ff42b5d6a8ba24d6ebfb88',1,'JOG2():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039a15421bcb42ff42b5d6a8ba24d6ebfb88',1,'JOG2():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a15421bcb42ff42b5d6a8ba24d6ebfb88',1,'JOG2():&#160;camada_dados.h']]]
];
