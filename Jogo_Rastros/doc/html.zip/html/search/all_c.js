var searchData=
[
  ['peca_5fbranca',['peca_branca',['../camada__logica_8h.html#aa3041511653989dbd8a4fa4d747deb4e',1,'camada_logica.c']]],
  ['peca_5fpreta',['peca_preta',['../camada__logica_8h.html#a88aed9dbea2e3e60f92d45f1741b5b11',1,'camada_logica.c']]],
  ['pos',['pos',['../camada__interface_8h.html#a4b364079a828570843b666d1babaccd7',1,'camada_interface.c']]],
  ['posicao_5fvalida',['posicao_valida',['../camada__logica_8h.html#ada40878b15d13766c1bc39a643bca062',1,'camada_logica.c']]],
  ['preta',['PRETA',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'PRETA():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'PRETA():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'PRETA():&#160;camada_dados.h']]],
  ['proximo',['proximo',['../auxiliares_8h.html#ad9380152361127432c55c1c6067e05ae',1,'proximo(LISTA L):&#160;auxiliares.c'],['../listas_8h.html#ad9380152361127432c55c1c6067e05ae',1,'proximo(LISTA L):&#160;auxiliares.c']]]
];
