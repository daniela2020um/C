var searchData=
[
  ['to_5fint',['to_int',['../auxiliares_8h.html#a5bf23e2e67f5cc232d1281ad8d3589ff',1,'to_int(char v[]):&#160;auxiliares.c'],['../camada__logica_8h.html#a5bf23e2e67f5cc232d1281ad8d3589ff',1,'to_int(char v[]):&#160;auxiliares.c']]],
  ['to_5fstring',['to_string',['../auxiliares_8h.html#a91008dcf7eed26e9f8986c527dd7b2d3',1,'to_string(int x, int y):&#160;auxiliares.c'],['../camada__logica_8h.html#a91008dcf7eed26e9f8986c527dd7b2d3',1,'to_string(int x, int y):&#160;auxiliares.c']]]
];
