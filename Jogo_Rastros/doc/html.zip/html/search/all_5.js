var searchData=
[
  ['gravar',['gravar',['../auxiliares_8h.html#a0f002a3e1122d65b85d09213886f26fe',1,'gravar(ESTADO *e, char fich[], int turno):&#160;auxiliares.c'],['../camada__interface_8h.html#a0f002a3e1122d65b85d09213886f26fe',1,'gravar(ESTADO *e, char fich[], int turno):&#160;auxiliares.c']]],
  ['guarda_5fjogada',['guarda_jogada',['../camada__logica_8h.html#ad45761e978e0d934e639d5bc4da09e7e',1,'camada_logica.c']]]
];
