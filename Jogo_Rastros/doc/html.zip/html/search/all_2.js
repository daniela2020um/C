var searchData=
[
  ['camada_5fdados_2eh',['camada_dados.h',['../camada__dados_8h.html',1,'']]],
  ['camada_5finterface_2eh',['camada_interface.h',['../camada__interface_8h.html',1,'']]],
  ['camada_5flogica_2eh',['camada_logica.h',['../camada__logica_8h.html',1,'']]],
  ['casa',['CASA',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039',1,'CASA():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039',1,'CASA():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039',1,'CASA():&#160;camada_dados.h']]],
  ['comando_5fjog',['comando_jog',['../bot_8h.html#a29270b43a7d3a47f53fc066b6b658906',1,'comando_jog(ESTADO *e):&#160;bot.c'],['../camada__interface_8h.html#a1b42c599f925ba04f3286653e46f6df4',1,'comando_jog(LISTA l, ESTADO *e, int turno):&#160;camada_interface.c']]],
  ['comando_5fjog2',['comando_jog2',['../camada__interface_8h.html#a9153a7472c62aba74c9f5febbaa62929',1,'camada_interface.c']]],
  ['conta_5fpretas',['conta_pretas',['../camada__interface_8h.html#a4f8813554c38eb990b468532e6c60c6c',1,'camada_interface.c']]],
  ['coordenada',['COORDENADA',['../structCOORDENADA.html',1,'']]],
  ['criar_5flista',['criar_lista',['../auxiliares_8h.html#ae3b99323b6f8f35d80bb69ff1a27985e',1,'criar_lista():&#160;auxiliares.c'],['../listas_8h.html#ae3b99323b6f8f35d80bb69ff1a27985e',1,'criar_lista():&#160;auxiliares.c']]]
];
