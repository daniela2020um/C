var searchData=
[
  ['jog1',['JOG1',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039a8ff080ca8f3143a71121a37a8e6596d8',1,'JOG1():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039a8ff080ca8f3143a71121a37a8e6596d8',1,'JOG1():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a8ff080ca8f3143a71121a37a8e6596d8',1,'JOG1():&#160;camada_dados.h']]],
  ['jog2',['JOG2',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039a15421bcb42ff42b5d6a8ba24d6ebfb88',1,'JOG2():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039a15421bcb42ff42b5d6a8ba24d6ebfb88',1,'JOG2():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a15421bcb42ff42b5d6a8ba24d6ebfb88',1,'JOG2():&#160;camada_dados.h']]],
  ['jogada',['JOGADA',['../structJOGADA.html',1,'']]],
  ['jogadas',['jogadas',['../structESTADO.html#afae43b87a488fad0f2b56a18bad31d18',1,'ESTADO::jogadas()'],['../auxiliares_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;auxiliares.h'],['../bot_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;bot.h'],['../camada__dados_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;camada_dados.h']]],
  ['jogadas_5fpossiveis',['jogadas_possiveis',['../auxiliares_8h.html#a1aea03240fe093e7eef97e0412298e7b',1,'jogadas_possiveis(ESTADO *e, LISTA l):&#160;auxiliares.c'],['../camada__logica_8h.html#a1aea03240fe093e7eef97e0412298e7b',1,'jogadas_possiveis(ESTADO *e, LISTA l):&#160;auxiliares.c']]],
  ['jogador_5fatual',['jogador_atual',['../structESTADO.html#a5dd28e2e68b7aef2b6b7ea88e02eff58',1,'ESTADO']]],
  ['jogar',['jogar',['../camada__interface_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;camada_logica.c'],['../camada__logica_8h.html#ac313d7e553b1e2b5f266acb9bfff8141',1,'jogar(ESTADO *e, COORDENADA c):&#160;camada_logica.c']]]
];
