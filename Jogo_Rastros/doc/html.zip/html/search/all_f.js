var searchData=
[
  ['vazio',['VAZIO',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039abc711f491a56ec7af7a688be508c5113',1,'VAZIO():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039abc711f491a56ec7af7a688be508c5113',1,'VAZIO():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039abc711f491a56ec7af7a688be508c5113',1,'VAZIO():&#160;camada_dados.h']]]
];
