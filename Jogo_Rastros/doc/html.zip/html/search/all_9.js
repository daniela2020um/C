var searchData=
[
  ['mostra_5fcoordenada',['mostra_coordenada',['../camada__interface_8h.html#a64b0d1727bd77bf55502f17ee0a54594',1,'camada_interface.c']]],
  ['mostra_5fresultado',['mostra_resultado',['../camada__interface_8h.html#aaf43f8c33d95a67f541fe4616b30bf28',1,'camada_interface.c']]],
  ['mostrar_5ftabuleiro',['mostrar_tabuleiro',['../auxiliares_8h.html#aa0b6c1689e60ac852a73d67e066c1df5',1,'mostrar_tabuleiro(ESTADO *e):&#160;auxiliares.c'],['../camada__interface_8h.html#aa0b6c1689e60ac852a73d67e066c1df5',1,'mostrar_tabuleiro(ESTADO *e):&#160;auxiliares.c']]],
  ['movs',['movs',['../camada__interface_8h.html#a94958a772c2216df312b19e13622700f',1,'camada_interface.c']]]
];
