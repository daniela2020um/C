var searchData=
[
  ['inicializar_5festado',['inicializar_estado',['../auxiliares_8h.html#a7e0c7e26fb685d9ab501e19b05e6954f',1,'inicializar_estado():&#160;auxiliares.c'],['../camada__dados_8h.html#a7e0c7e26fb685d9ab501e19b05e6954f',1,'inicializar_estado():&#160;auxiliares.c']]],
  ['insere_5fcabeca',['insere_cabeca',['../auxiliares_8h.html#a37ba5fc3cfddb6bc94d4b54b00bc696e',1,'insere_cabeca(LISTA L, void *valor):&#160;auxiliares.c'],['../listas_8h.html#a37ba5fc3cfddb6bc94d4b54b00bc696e',1,'insere_cabeca(LISTA L, void *valor):&#160;auxiliares.c']]],
  ['interpretador',['interpretador',['../camada__interface_8h.html#a24da95ebeede4a540e37790ce8be359b',1,'camada_interface.c']]]
];
