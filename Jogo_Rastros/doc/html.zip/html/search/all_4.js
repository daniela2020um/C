var searchData=
[
  ['encurralada',['encurralada',['../auxiliares_8h.html#a5679b2ed29ad7be4b942dd7ce0562a4e',1,'encurralada(ESTADO *e):&#160;camada_logica.c'],['../camada__logica_8h.html#a5679b2ed29ad7be4b942dd7ce0562a4e',1,'encurralada(ESTADO *e):&#160;camada_logica.c']]],
  ['estado',['ESTADO',['../structESTADO.html',1,'']]]
];
