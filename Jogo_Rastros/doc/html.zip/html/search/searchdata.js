var indexSectionsWithContent =
{
  0: "abcdegijlmnoprtv",
  1: "cejn",
  2: "abcl",
  3: "acdegijlmnoprt",
  4: "jnt",
  5: "jl",
  6: "c",
  7: "bjpv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos",
  6: "Enumerações",
  7: "Valores de enumerações"
};

