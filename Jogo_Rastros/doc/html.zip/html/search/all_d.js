var searchData=
[
  ['remove_5fcabeca',['remove_cabeca',['../listas_8h.html#a9026a681a68322b5ec7f07137b864cbd',1,'listas.c']]]
];
