var searchData=
[
  ['deteta_5ffim',['deteta_fim',['../camada__interface_8h.html#a46dad883a01f5f7b06944a3bbe317b84',1,'deteta_fim(ESTADO *e):&#160;camada_logica.c'],['../camada__logica_8h.html#a46dad883a01f5f7b06944a3bbe317b84',1,'deteta_fim(ESTADO *e):&#160;camada_logica.c']]],
  ['devolve_5fcabeca',['devolve_cabeca',['../auxiliares_8h.html#abfcb205f3eb670157be0d1221021714b',1,'devolve_cabeca(LISTA L):&#160;auxiliares.c'],['../listas_8h.html#abfcb205f3eb670157be0d1221021714b',1,'devolve_cabeca(LISTA L):&#160;auxiliares.c']]],
  ['dist',['dist',['../auxiliares_8h.html#a43134a0efdc6f282be9a7f83997e8fc9',1,'dist(int x, int y, int z, int w):&#160;auxiliares.c'],['../camada__logica_8h.html#a43134a0efdc6f282be9a7f83997e8fc9',1,'dist(int x, int y, int z, int w):&#160;auxiliares.c']]]
];
