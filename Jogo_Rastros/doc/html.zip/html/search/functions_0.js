var searchData=
[
  ['acabou',['acabou',['../camada__logica_8h.html#a650916d9bd6f0648c54af321cd1ab655',1,'camada_logica.c']]]
];
