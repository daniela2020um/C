var searchData=
[
  ['num',['num',['../camada__interface_8h.html#a70bfbeadc5be12c9cb3110cba47c2694',1,'auxiliares.c']]]
];
