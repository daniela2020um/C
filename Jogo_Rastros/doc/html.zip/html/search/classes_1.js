var searchData=
[
  ['estado',['ESTADO',['../structESTADO.html',1,'']]]
];
