var searchData=
[
  ['jogadas',['JOGADAS',['../auxiliares_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;auxiliares.h'],['../bot_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;bot.h'],['../camada__dados_8h.html#a94c221d29a1760f008b7834093259b7d',1,'JOGADAS():&#160;camada_dados.h']]]
];
