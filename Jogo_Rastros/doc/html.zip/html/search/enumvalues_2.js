var searchData=
[
  ['preta',['PRETA',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'PRETA():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'PRETA():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039a007278eb3827d19891b47cdd3ac8846d',1,'PRETA():&#160;camada_dados.h']]]
];
