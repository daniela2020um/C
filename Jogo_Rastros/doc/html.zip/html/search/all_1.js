var searchData=
[
  ['bot_2eh',['bot.h',['../bot_8h.html',1,'']]],
  ['branca',['BRANCA',['../auxiliares_8h.html#aba91601f16d4c485b2d9b8c429f27039ad24485fddec75419fd4a0cc9edda0ca5',1,'BRANCA():&#160;auxiliares.h'],['../bot_8h.html#aba91601f16d4c485b2d9b8c429f27039ad24485fddec75419fd4a0cc9edda0ca5',1,'BRANCA():&#160;bot.h'],['../camada__dados_8h.html#aba91601f16d4c485b2d9b8c429f27039ad24485fddec75419fd4a0cc9edda0ca5',1,'BRANCA():&#160;camada_dados.h']]]
];
