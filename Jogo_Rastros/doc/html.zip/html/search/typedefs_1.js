var searchData=
[
  ['lista',['LISTA',['../auxiliares_8h.html#a5a5447a03bcb835183312f000a1d12bc',1,'LISTA():&#160;auxiliares.h'],['../bot_8h.html#a5a5447a03bcb835183312f000a1d12bc',1,'LISTA():&#160;bot.h'],['../listas_8h.html#a5a5447a03bcb835183312f000a1d12bc',1,'LISTA():&#160;listas.h']]]
];
